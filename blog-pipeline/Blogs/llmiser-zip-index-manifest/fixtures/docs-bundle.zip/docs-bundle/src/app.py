def main():
    return 'ok'
