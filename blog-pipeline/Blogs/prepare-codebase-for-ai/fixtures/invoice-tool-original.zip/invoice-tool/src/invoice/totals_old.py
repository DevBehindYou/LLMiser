# Obsolete version kept 'just in case'
def invoice_total(lines):
    return round(sum(q * float(p) for q, p in lines), 2)
