# invoice-tool

Small CLI that totals invoice lines and prints a summary.

Run `python -m invoice.cli lines.csv`. Tests: `pytest`.
