import leftPad from 'left-pad';
export const label = (n) => leftPad(String(n), 8);
