from decimal import Decimal

from invoice.totals import invoice_total


def test_round_once_not_per_line():
    # Three lines of 0.005: rounded once the total is 0.015 -> 0.02.
    # Rounding each line first gives 0.01 + 0.01 + 0.01 = 0.03.
    assert invoice_total([(1, "0.005")] * 3) == Decimal("0.02")
