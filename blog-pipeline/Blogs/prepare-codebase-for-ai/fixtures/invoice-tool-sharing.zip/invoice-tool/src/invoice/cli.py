import csv
import sys

from invoice.totals import invoice_total


def main(path: str) -> None:
    with open(path, newline="") as handle:
        lines = [(int(row["qty"]), row["unit_price"]) for row in csv.DictReader(handle)]
    print(f"Total: {invoice_total(lines)}")


if __name__ == "__main__":
    main(sys.argv[1])
