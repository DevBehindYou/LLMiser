from decimal import Decimal, ROUND_HALF_UP


def line_total(quantity: int, unit_price: str) -> Decimal:
    """Price of one invoice line, rounded to cents."""
    return (Decimal(unit_price) * quantity).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def invoice_total(lines: list[tuple[int, str]]) -> Decimal:
    # BUG under review: rounds each line, then sums. Finance wants the sum rounded once.
    return sum((line_total(q, p) for q, p in lines), Decimal("0"))
