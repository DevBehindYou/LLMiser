Patched from acme-money 2.1.4 to remove a logging call. Rounding unchanged.
