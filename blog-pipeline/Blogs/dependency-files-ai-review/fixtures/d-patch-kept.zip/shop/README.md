# shop

Question for review: why does total(2.675) return 2.67, not 2.68?
The rounding code is a patched copy of acme-money, kept under patches/ in this sharing copy (vendor/ in the working folder).
