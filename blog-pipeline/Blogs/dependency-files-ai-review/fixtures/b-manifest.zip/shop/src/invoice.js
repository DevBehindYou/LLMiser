const { round } = require('../vendor/acme-money/round');

function total(amount) {
  return round(amount, 2);
}

module.exports = { total };
