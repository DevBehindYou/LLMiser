const { total } = require('../src/invoice');

test('rounds half up to cents', () => {
  expect(total(2.675)).toBe(2.68); // fails: returns 2.67
});
